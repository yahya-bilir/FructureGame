﻿using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace Factories
{
    public class EnemyFactoryManager : MonoBehaviour
    {
        [SerializeField] private List<EnemyFactory> enemyFactories;
        [SerializeField] private float staticSpawnInterval = 1f;
        private async UniTask Start()
        {
            UniTask.WaitForSeconds(staticSpawnInterval);
            
        }
    }
}